package com.minegocio.cigarros;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * Venta de Cigarros: la app vive dentro del teléfono (assets/index.html) y guarda todo en el teléfono.
 * Funciona sin internet. Solo sale a internet si se comparte por WhatsApp.
 */
public class MainActivity extends Activity {
    static final String FOLDER = "Venta de Cigarros";
    static final int REQ_FILE = 51;

    WebView web;
    ValueCallback<Uri[]> fileCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#F6F1EA"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setSupportZoom(false);
        web.addJavascriptInterface(new Bridge(), "CigApp");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception e) { toast("No se pudo abrir"); }
                return true;
            }
        });
        web.setWebChromeClient(new Chrome());
        web.loadUrl("file:///android_asset/index.html");
    }

    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    class Chrome extends WebChromeClient {
        @Override
        public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
            new AlertDialog.Builder(MainActivity.this).setMessage(msg).setPositiveButton("OK", (d, w) -> r.confirm())
                    .setOnCancelListener(d -> r.confirm()).show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
            new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                    .setPositiveButton("Sí", (d, w) -> r.confirm())
                    .setNegativeButton("No", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView v, String url, String msg, String def, JsPromptResult r) {
            EditText e = new EditText(MainActivity.this);
            e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            if (def != null) { e.setText(def); e.setSelection(def.length()); }
            LinearLayout box = new LinearLayout(MainActivity.this);
            box.setPadding(dp(20), dp(4), dp(20), 0);
            box.addView(e, new LinearLayout.LayoutParams(-1, -2));
            new AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(box)
                    .setPositiveButton("OK", (d, w) -> r.confirm(e.getText().toString()))
                    .setNegativeButton("Cancelar", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        /** «Cargar un respaldo»: elegir el archivo .json del teléfono (Descargas, WhatsApp, Drive…). */
        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            try { startActivityForResult(Intent.createChooser(i, "Elegir el respaldo"), REQ_FILE); }
            catch (Exception e) { fileCb = null; cb.onReceiveValue(null); toast("No se pudo abrir los archivos"); }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FILE || fileCb == null) return;
        Uri u = res == RESULT_OK && data != null ? data.getData() : null;
        fileCb.onReceiveValue(u == null ? null : new Uri[]{u});
        fileCb = null;
    }

    class Bridge {
        @JavascriptInterface
        public String version() { return "1.0"; }

        /** Guarda el archivo (respaldo o ventas) en Descargas → Venta de Cigarros y ofrece enviarlo. */
        @JavascriptInterface
        public void saveFile(String b64, String mime, String name) {
            runOnUiThread(() -> {
                Uri u = writeDownload(b64, mime, name);
                if (u == null) return;
                new AlertDialog.Builder(MainActivity.this).setTitle("Guardado ✅")
                        .setMessage("Está en Descargas → " + FOLDER + ":\n" + name)
                        .setPositiveButton("Enviar", (d, w) -> {
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType(mime);
                            i.putExtra(Intent.EXTRA_STREAM, u);
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            try { startActivity(Intent.createChooser(i, "Enviar " + name)); } catch (Exception e) { toast("No se pudo compartir"); }
                        })
                        .setNeutralButton("Abrir", (d, w) -> {
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setDataAndType(u, mime);
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                            try { startActivity(i); } catch (Exception e) { toast("No hay una app para abrirlo"); }
                        })
                        .setNegativeButton("OK", null).show();
            });
        }

        /** Resumen del día: abre WhatsApp (o lo que elija) con el texto. */
        @JavascriptInterface
        public void shareText(String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                try { startActivity(Intent.createChooser(i, "Enviar resumen")); } catch (Exception e) { toast("No se pudo compartir"); }
            });
        }
    }

    Uri writeDownload(String b64, String mime, String name) {
        try {
            byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) throw new Exception("sin espacio");
                java.io.OutputStream os = getContentResolver().openOutputStream(u);
                os.write(data);
                os.close();
                return u;
            }
            if (checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 9);
                toast("Acepta el permiso y vuelve a intentarlo");
                return null;
            }
            java.io.File dir = new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER);
            dir.mkdirs();
            java.io.File f = new java.io.File(dir, name);
            java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
            fo.write(data);
            fo.close();
            android.os.StrictMode.setVmPolicy(new android.os.StrictMode.VmPolicy.Builder().build());
            return Uri.fromFile(f);
        } catch (Exception e) {
            toast("No se pudo guardar: " + e.getMessage());
            return null;
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){try{return atras()}catch(e){return 0}})()", v -> {
            if (!"1".equals(v)) MainActivity.super.onBackPressed();
        });
    }
}

# Venta de Cigarros — Android v1.0
Venta de cigarros por caja y por sueltos, en CUP. Funciona sin internet: los datos se guardan en el teléfono.
Marcas con precio de caja y de suelto, inventario en cajas + sueltos, fiados, ganancia, reportes por día/semana/mes,
resumen por WhatsApp, descarga de ventas (CSV para Excel) y respaldo.
Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).
